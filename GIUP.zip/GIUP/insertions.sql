﻿--create database GIUP
--go
--use GIUP
--create table users (
--ID int identity ,
--email varchar (50),
--username varchar (20),
--user_password varchar (20),
--primary key (ID),
--);
--create table Student(
--s_ID int  ,
--first_name varchar(20),
--middle_name varchar(20),
--last_name varchar(20),
--GIU_id int,
--birth_date date,
--age as year(CURRENT_TIMESTAMP) - year(birth_date),
--faculty varchar (20),
--semester int ,
--major varchar(20),
--GPA decimal (4,2),
--Student_Address varchar(50) ,
--CV varchar (500),
--cover_letter varchar (500),
--primary key(s_ID),
--foreign key (s_ID) references users on delete cascade on update cascade,
--);
--create table Student_Phonenumber (
--id int,
--phone_number int ,
--primary key(id, phone_number),
--foreign key(id) references Student on delete cascade on update cascade,
--);
--create table employer(
--id int ,
--company_name varchar (20),
--employer_address varchar(50),
--phone_number int,
--fax_number varchar (15),
--website varchar (20),
--business varchar(20),
--establishment_year date,
--country_of_origin varchar (20),
--industry varchar (20),
--number_of_current_employees int,
--products_or_services varchar(20),
--primary key (id),
--foreign key (id) references Users on delete cascade on update cascade,
--);
--create table contact_person(
--employer_id int,
--contactPerson_name varchar (20),
--job_title varchar (20),
--email varchar (20),
--mobile_number int ,
--fax varchar (20),
--primary key (employer_id),
--foreign key (employer_id) references Employer on delete cascade on update cascade,
--);

--create table HR_Director(

--employer_id int,
--HRDirector_name varchar(20),
--email varchar(20),

--primary key (employer_id),
--foreign key (employer_id) references Employer on delete cascade on update cascade,
--);

--create table Admin(
--id int, 
--primary key (id),
--foreign key (id) references Users on delete cascade on update cascade
--);


--create table Faculty_Representative(
--id int ,
--faculty varchar(20),
--primary key(id),
--foreign key (id) references Users on delete cascade on update cascade,
--);

--create table Academic_Advisor(
--id int ,
--faculty varchar(20),
--primary key(id),
--foreign key (id) references Users on delete cascade on update cascade,
--);

--create table Career_Office_Coordinator(
--id int, 
--primary key (id),
--foreign key (id) references Users on delete cascade on update cascade
--);


--create table Review_Profile(
--employer_id int,
--admin_id int ,
--profile_status varchar(40),
--reason varchar(100),
--primary key(employer_id),
--foreign key (employer_id) references Employer on delete no action on update no action,
--foreign key (admin_id) references Admin on delete no action on update no action ,
--);

--create table Job(

--id int identity,
--title varchar(20),
--job_description varchar(100),
--department varchar(30),
--job_start_date date,
--end_date date,
--duration AS (YEAR(end_date)-YEAR(job_start_date)),
--application_deadline date ,
--num_of_availabe_internships int,
--salary_range varchar(20),
--qualifications varchar(100),
--job_location varchar(20),
--application_link varchar(50),
--application_email varchar(50),
--job_type varchar(30),
--employer_id int,
--admin_id int,
--visibility bit,
--reason varchar(100),
--primary key (id ),
--foreign key (employer_id) references Employer on delete cascade on update no action ,
--foreign key (admin_id) references Admin on delete no action on update no action,
--);


--create table Allowed_faculties(

--id int, 
--faculty_name varchar(30),
 
-- primary key (id,faculty_name),
-- foreign key (id) references job on delete cascade on update cascade,
-- );

-- create table Required_semesters(

-- id int ,
-- semester int,
-- primary key (id,semester),
-- foreign key (id) references job on delete cascade on update cascade,

-- );

-- create table part_time(
-- id int,
-- workdays int,
-- primary key (id),
-- foreign key (id) references job on delete cascade on update cascade,
-- );
-- CREATE TABLE Freelance(
-- id int,
-- primary key(id),
-- foreign key (id) references job on delete cascade on update cascade,
-- );
-- CREATE TABLE summerInternship(
-- id int,
-- primary key(id),
-- foreign key (id) references job on delete cascade on update cascade
-- );
-- CREATE TABLE projectBased(
-- id int,
-- primary key(id),
-- foreign key (id) references job on delete cascade on update cascade
-- );
-- CREATE TABLE fulltime(
-- id int,
-- primary key(id),
-- foreign key (id) references job on delete cascade on update cascade
-- );


-- create table Industrial_Internship(
-- id int,
-- Internship_status bit,
-- aa_id int,
-- facultyRep_id int,

-- primary key(id) ,
-- foreign key(id) references job on delete cascade on update cascade,
-- foreign key(aa_id) references Academic_Advisor on delete no action on update no action,
-- foreign key(facultyRep_id) references Faculty_Representative on delete no action on update no action,
-- );
-- create table CV_Builder(
-- personal_mail varchar(50),
-- education varchar(100),
-- extracurricular_activities varchar(300),
-- linkedIn_link varchar(30),
-- github_link varchar(30),
-- skills varchar(300),
-- achievements varchar(300),
-- student_id int,
-- primary key(personal_mail),
-- foreign key (student_id) references Student on delete cascade on update cascade,
-- );
-- create table Applies(
-- student_id int,
-- job_id int,
-- application_status bit,

-- primary key (student_id, job_id),
-- foreign key (student_id) references Student on delete no action on update no action,
-- foreign key (job_id) references job on delete no action on update no action,

-- );
-- create table Eligible(
-- student_id int ,
-- II_id int,
-- coc_id int,
-- eligibility bit,
-- primary key (student_id, II_id),
-- foreign key (student_id) references Student on delete no action on update no action,
-- foreign key (II_id) references Industrial_Internship on delete no action on update no action,
-- foreign key (coc_id) references Career_Office_Coordinator on delete no action on update no action,
-- );
-- CREATE TABLE progressReport (
-- student_id int,
-- report_date date,
-- numeric_state int,
-- evaluation varchar (60),
-- description varchar(100),
-- advisor_id int ,
-- primary key (student_id,report_date),
-- foreign key (student_id) references student on delete no action on update no action,
-- foreign key (advisor_id) references Academic_Advisor on delete no action on update no action 
-- );
 
 
--insert into users (email,username,user_password) 
--values ('nadinenash@gmail.com', 'Nash','nash123')

--insert into users values ('morayasser2009@hotmail.com','ammar','mory')
--insert into users values ('jumananounou@gmail.com', 'jumana','Joo')
--insert into users values ('suzanwael@hotmail.com','susaan','SOoozy')
--insert into users values ('rohaidmohamed@hotmail.com','rohaid.mohamed','RORO')
--insert into users values ('ahmedhatem@hotmail.com','ahmed.hatem','hatot')
--insert into users values ('maryhaneslam@giumail.com','maryhan.eslam','maryy2002')
--insert into users values ('hayamohamed@giumail.com','haya.mohamed','hayoy2002')
--insert into users values ('mohamedwael@giumail.com','mohamed.mabrouk','mabrouk2002')
--insert into users values ('nadineyasser@hotmail.com','nadine.yasser','nadoo1999')
--insert into users values ('sherifakram@giumail.com','sherif.Akram','shikooo')
--insert into users values ('sarasherif@hotmail.com','maryhan.eslam','maryy2002')
--insert into users values ('amrhany@hotmail.com','amrr.hany','primelegend')
--insert into users values ('ahmedkroush@hotmail.com','ahmed.kroush','kerr')
--insert into users values ('nadasharaf@hotmail.com','nada.sharaf','NadA1922')
--insert into users values ('amrmougy@hotmail.com','amr.elmougy','amooora')
--insert into users values ('moustafaelagamy@hotmail.com','moustafa.elagamy','MOUSTAFAAA')
--insert into users values ('elonmusk@hotmail.com','elon.musk','teslaguy')
--insert into users values ('carolinedatabase@hotmail.com','caroline.medhat','caroline1990')
--insert into users values ('farouksameh@hotmail.com','farouk.sameh','ro2aaa')
--insert into users values ('dimanader@hotmail.com','dima.nader','dimaah')
--insert into users values ('ziadezz@hotmail.com','ziad.ezz','levi')
--insert into users values ('ahmedsha3ban@hotmail.com','ahmed.sha3ban','sha3bo')
--insert into users values ('alyazazy@hotmail.com','aly.azazy','azooz')
--insert into users values ('mennasingergy@hotmail.com','menna.singergy','synergy')
--insert into users values ('nadatarek@hotmail.com','nada.tarel','toby')
--insert into users values ('sohailakhaled@hotmail.com','sohaila.khaled','soohailaaa')
--insert into users values ('kamelkassab@hotmail.com','kamel.kassab','Rakii')


--insert into Student(s_ID,first_name,middle_name,last_name,GIU_id,faculty,semester,major,GPA) values (1,'nadine','nashaat','abdelaal',200621, 'COMPUiTER SCIENCE',3,'data science',0.7) 
--insert into Student(s_ID,first_name,middle_name,last_name,GIU_id,birth_date,faculty,semester,major,GPA) values (2,'ammar','yasser','mohamed',2004785,'2002-04-10','COMPUiTER SCIENCE',3,'software engineering',1.4) 
--insert into Student(s_ID,first_name,middle_name,last_name,GIU_id,birth_date,faculty,semester,major,GPA) values (3,'jumana','amr','nounou',200311, '2002-04-21','engineering',3,'robotics',0.9) 
--insert into Student(s_ID,first_name,middle_name,last_name,GIU_id,birth_date,faculty,semester,major,GPA) values (4,'suzan','mohamed','wael',2002592, '2003-12-12','design',2,'fashion design',0.8) 
--insert into Student(s_ID,first_name,middle_name,last_name,GIU_id,birth_date,faculty,semester,major,GPA) values (14,'ahmed','moustafa','kroush',2001442, '2003-10-10','business',2,'marketing',1.1) 
--insert into Job (title, job_description, department, job_location, employer_id, admin_id)
--values('secretary', ' beginner', 'admission', 'b1', 10, 9)

--insert into Job (title, job_description, department, job_location, employer_id, admin_id)
--values('security', ' beginner', 'computer science', 'b2', 12, 6)

--insert into Job (title, job_description, department, job_location, employer_id, admin_id)
--values('tutor', ' has masters ', 'engineering', 'b3', 11, 8)

--insert into Job (title, job_description, department, job_location, employer_id, admin_id)
--values('assistant', ' beginner', 'dentistry', 'b4', 11, 6)

--insert into Job (title, job_description, department, job_location, employer_id, admin_id,visibility)
--values ('fashion designer','works under preassure', 'design','b5',13,9,1)



--Insert into employer ( id,company_name, employer_address ,phone_number, fax_number)
--values( 11,'oracle','fifth settlement', 010364364,'fs7435')

--Insert into employer ( id,company_name, employer_address ,phone_number, fax_number)
--values( 12,'Microsoft ','October city ', 010573847,'gr3628')

--Insert into employer ( id,company_name, employer_address ,phone_number, fax_number)
--values( 13,'apple','Nasr city', 011345849,'yt5647')

--Insert into employer ( id,company_name, employer_address ,phone_number, fax_number)
--values( 10,'peace cake','Maadi', 012474338 ,'ty7483')
--insert into Admin values (6)
--insert into Admin values (7)
--insert into Admin values (8)
--insert into Admin values (9)

--insert into Review_Profile (admin_id,employer_id,profile_status,reason)
--values(7,12,'false','doesnt come on time')
--insert into Review_Profile (admin_id,employer_id,profile_status,reason)
--values(7,13,'false','descipline issues')
--insert into Review_Profile (admin_id,employer_id,profile_status,reason)
--values(8,11,'true',null)
--insert into Review_Profile (admin_id,employer_id,profile_status,reason)
--values(9,10,'true',null)
--insert into Faculty_Representative values (1,'design')
--insert into Faculty_Representative values (15,'computer science')
--insert into Faculty_Representative values (16,'industrial')
--insert into Faculty_Representative values (17,'business')
--insert into Applies values  (4,6,'1')
--insert into Applies values  (4,8,'1')
--insert into Applies values  (2,6,'1')
--insert into Applies values  (14,7,'1')
--insert into Academic_Advisor values(20,'engineering')
--insert into Academic_Advisor values(21,'computer science')
--insert into Academic_Advisor values(22,'design')
--insert into Academic_Advisor values(23,'business')
--insert into Allowed_faculties values (1,'business')
--insert into Allowed_faculties values (1,'engineering')
--insert into Allowed_faculties values (2,'engineering')
--insert into Allowed_faculties values (2,'computer science')
--insert into Allowed_faculties values (3,'biotechnology')
--insert into Allowed_faculties values (4,'business')
--insert into Allowed_faculties values (4,'design')
--insert into Allowed_faculties values (7,'engineering')
--insert into Faculty_Representative values (26,'engineering')
--insert into Faculty_Representative values (27,'business')
--insert into Faculty_Representative values (28,'design')

--insert into Industrial_Internship values (5,'true',22,28)
--insert into progressReport values (2,'2021-05-12',null,null,'report of total codes',23)
--insert into progressReport values (2,'2021-07-12',null,null,'report of total codes2',23)
--insert into progressReport values (2,'2021-02-12',null,null,'report of total codes3',23)
--insert into progressReport values (2,'2021-01-12',null,'verygood','report of total codes3',23)
--insert into progressReport values (3,'2021-09-12',null,null,'report of total designs',22)
--insert into progressReport values (3,'2021-11-12',null,null,'report of total designs2',22)
insert into job values(66,'programmer','codes','IT',null,null,null,67,80000,null,'cairo',null,null,null,29,9,1,null)
insert into job values(67,'cook','coffee','drinks',null,null,null,67,80000,null,'cairo',null,null,null,30,9,0,null)
insert into job values(68,'baker','bakes','cookies',null,null,null,67,80000,null,'cairo',null,null,null,31,9,1,null)








------drop database GIUP

