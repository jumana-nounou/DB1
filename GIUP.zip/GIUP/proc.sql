﻿--use GIUP


--CREATE PROCEDURE GENERATEPWD @OUTMESSAGE VARCHAR(8) OUTPUT  
--AS   
--BEGIN  
--SET NOCOUNT ON  
--declare @LENGTH INT,@CharPool varchar(26),@PoolLength varchar(26),@LoopCount  INT  
--DECLARE @RandomString VARCHAR(8),@CHARPOOLINT VARCHAR(9)  
  
    
--SET @CharPool = 'A!B@C!123D#E@FG#13511H$276IJ$34K%LM%86332N*PQR%ST&U*V(W)X_YZ1412'  
--DECLARE @TMPSTR VARCHAR(3)  

--SET @PoolLength = DataLength(@CharPool)  
--SET @LoopCount = 0  
--SET @RandomString = ''  
  
--    WHILE (@LoopCount <8)  
--    BEGIN  
--        SET @TMPSTR =   SUBSTRING(@Charpool, CONVERT(int, RAND() * @PoolLength), 1)           
--        SELECT @RandomString  = @RandomString + CONVERT(VARCHAR(5), CONVERT(INT, RAND() * 8))  
--        IF(DATALENGTH(@TMPSTR) > 0)  
--        BEGIN   
--            SELECT @RandomString = @RandomString + @TMPSTR    
--            SELECT @LoopCount = @LoopCount + 1  
--        END  
--    END  
--    SET @LOOPCOUNT = 0   
--    set @OUTMESSAGE=@RandomString 

--END    
--go




-- CREATE PROC ShowEmployers 
-- as
-- select *
-- from employer
-- inner join Review_Profile on Review_Profile.employer_id= employer.id
-- where Review_Profile.profile_status = 'true'
-- order by employer.company_name asc  
-- go



-- CREATE PROC ShowJobs 
-- as 
-- select * 
-- from job 
-- where visibility > 0 
-- go
 

--CREATE PROC JobsSearch 
-- @semester int, @allowed_faculty varchar(20)
--as
--IF(EXISTS(
--select * 
--from job
--inner join Allowed_faculties on Allowed_faculties.id=job.id
--inner join Required_semesters on Required_semesters.id=job.id
--where Allowed_faculties.faculty_name = @allowed_faculty or Required_semesters.semester=@semester 
--))
--begin 
--select * 
--from job
--inner join Allowed_faculties on Allowed_faculties.id=job.id
--inner join Required_semesters on Required_semesters.id=job.id
--where Allowed_faculties.faculty_name = @allowed_faculty or Required_semesters.semester=@semester 
--end
--ELSE(
--select *
--from job)
--go

--CREATE PROC UserRegister
--@usertype varchar(40),@email varchar(50),@first_name varchar(20),@middle_name varchar(20),
--@last_name varchar(20), @birth_date date,@GIU_id int,@semester int, @faculty varchar(20),@major
--varchar(20),@gpa decimal(4,2),@adress varchar(10), @company_name varchar(20), @company_phone
--varchar(20),@fax varchar(50), @company_website varchar(50), @type_of_business varchar(30), @establishment_year date, @origin_country varchar(20), @industry varchar(20), @n_current_employees
--int, @products_services varchar(30) , @username varchar(20),@password varchar (8) output
--as 
-- exec GENERATEPWD @password output
-- insert into users values ( @email , @username , @password)

--if @usertype = 'Student' 
--insert into Student ( s_ID,first_name, middle_name , last_name , birth_date , Student_Address , GIU_id , semester , faculty , major , GPA )
--values ( @@IDENTITY,@first_name, @middle_name , @last_name , @birth_date,@adress,@GIU_id, @semester,@faculty,@major,@gpa)
-- else if @usertype = 'Employer' 
--insert into employer ( id, employer_address,company_name , phone_number , fax_number , website, business, establishment_year, country_of_origin , industry , number_of_current_employees , products_or_services )
--values (@@IDENTITY,@adress , @company_name,@company_phone , @fax, @company_website, @type_of_business, @establishment_year,@origin_country,@industry, @n_current_employees, @products_services)
-- else if @usertype = 'Admin' 
--insert into Admin values (@@IDENTITY)
--else if @usertype ='Career office coordinator' 
-- insert into Career_Office_Coordinator(id) values (@@IDENTITY)
--else if @usertype= 'Faculty representative'
-- insert into Faculty_Representative(id,faculty) values (@@IDENTITY,@faculty)
-- else if @usertype='Advisor'
-- insert into Academic_Advisor(id,faculty) values(@@IDENTITY,@faculty)
-- else
-- print 'they are not read'
-- go 


-- create proc userLogin 
--  @email varchar(50), @password varchar(20),
--  @success bit output , @user_id int output, @usertype varchar(40) output
--  as
--  if(exists(
--  select email, user_password, ID
--  from users u
--  where u.email=@email and u.user_password=@password
--  ))
--  begin
--  select @user_id=ID
--  from users u
--   where u.email=@email and u.user_password=@password
--   if(exists(
--   select s_ID
--   from Student
--   where Student.s_ID=@user_id))
--   begin 
--   set @usertype='Student'
--   end

--   if(exists(
--   select id
--   from employer
--   where employer.id=@user_id))
--   begin 
--   set @usertype='Employer'
--   end

--  if(exists(
--   select id
--   from Admin
--   where admin.id=@user_id))
--   begin 
--   set @usertype='Admin'
--   end

--  if(exists(
--   select id
--   from Faculty_Representative
--   where Faculty_Representative.id=@user_id))
--   begin 
--   set @usertype='Faculty_Representative'
--   end

--   if(exists(
--   select id
--   from Career_Office_Coordinator
--   where Career_Office_Coordinator.id=@user_id))
--   begin 
--   set @usertype='Career_Office_Coordinator'
--   end
--   if(exists(
--   select id
--   from Academic_Advisor
--   where Academic_Advisor.id=@user_id))
--   begin 
--   set @usertype='Academic_Advisor'
--   end

--  set @success ='1'
--  print @success
--  print @user_id
--  print @usertype
--  end
--  ELSE
--  begin
--  set @success='0'
--  set @user_id=-1 
--  print @success
--  print @user_id
--  end
--  go


--create proc viewProfile 
-- @user_id int
-- as 
-- if(exists(
--  select distinct  * 
-- from users u1
-- inner join Student on Student.s_ID=u1.ID
-- where s_ID=@user_id and u1.ID=@user_id))
-- begin 
--  select distinct  * 
-- from users u1
-- inner join Student on Student.s_ID=u1.ID
-- where s_ID=@user_id and u1.ID=@user_id
-- end
-- else if(exists(
-- select distinct  * 
-- from users u1
-- inner join employer on employer.id=u1.ID
-- where  employer.id=@user_id and u1.ID=@user_id))
-- begin
--select distinct  * 
-- from users u1
-- inner join employer on employer.id=u1.ID
-- where employer.id=@user_id and u1.ID=@user_id
-- end
-- else if(exists(
--  select distinct  * 
-- from users 
-- inner join Admin on Admin.id=users.ID
-- where Admin.id=@user_id and users.ID=@user_id))
-- begin
-- select distinct  * 
-- from users 
-- inner join Admin on Admin.id=users.ID
-- where Admin.id=@user_id and users.ID=@user_id
-- end
-- else if(exists(
--  select distinct  * 
-- from users 
-- inner join Faculty_Representative on Faculty_Representative.id=users.ID
-- where Faculty_Representative.id=@user_id and users.ID=@user_id))
-- begin 
-- select distinct  * 
-- from users 
-- inner join Faculty_Representative on Faculty_Representative.id=users.ID
-- where Faculty_Representative.id=@user_id and users.ID=@user_id
-- end
-- else
-- begin
-- select *
-- from users
-- inner join Academic_Advisor on Academic_Advisor.id=users.ID
-- where Academic_Advisor.id=@user_id and users.ID=@user_id
-- end
-- go
 
---- exec viewProfile 10
---- drop procedure [viewProfile]
---- go
----drop procedure [viewProfile]
----exec viewProfile 1008

-- create proc deleteProfile
-- @user_id int
-- as
-- delete from users 
-- where users.ID=@user_id

-- delete from Student 
-- where @user_id=Student.s_ID

-- delete from Employer 
-- where @user_id=employer.id

-- delete from Career_Office_Coordinator 
-- where @user_id=Career_Office_Coordinator.id

-- delete from Faculty_Representative 
-- where @user_id=Faculty_Representative.id

-- delete from Admin 
-- where @user_id=Admin.id

-- delete from Academic_Advisor
-- where @user_id=Academic_Advisor.id
-- go
  
-- -- exec deleteProfile 21
--drop procedure [deleteProfile]
CREATE PROC deleteProfile
@user_id int
AS
DELETE FROM Users WHERE Users.id= @user_id ;


 DELETE FROM Progress_report
 WHERE Progress_report.student_id = @user_id 

 DELETE FROM Eligible
 WHERE Eligible.Student_id= @user_id 

 DELETE FROM Apply
 WHERE Apply.student_ID=@user_id 

 delete from Student 
 where Student.id=@user_id;

 
 DELETE FROM Job
 WHERE Job.employer_ID= @user_id

 DELETE FROM Review_Profile
 WHERE Review_Profile.employer_ID= @user_id

 delete from Employer 
 where Employer.id =@user_id;

 
 DELETE FROM Eligible
 WHERE Eligible.coc_id= @user_id

 delete from Career_Office_Coordinator 
 where Career_Office_Coordinator.id=@user_id;

 
 DELETE FROM Industrial_Internship
 WHERE Industrial_Internship.facultyRep_id= @user_id;

 delete from Faculty_Representative 
 where Faculty_Representative.id=@user_id;

 
 DELETE FROM Admin
 WHERE ADMIN.id= @user_id

 delete from Admin 
 where Admin.id=@user_id;

 
 DELETE FROM Industrial_Internship
 WHERE Industrial_Internship.aa_id=  @user_id

 delete from Academic_Advisor
 where Academic_Advisor.id=@user_id;


GO

--  create proc AdminViewEmps
--  as 
--  select * 
--  from employer 
--  go
--create proc viewAssignedEmployers
--@admin_id int
--as
--select *
--from Review_Profile
--where admin_id=@admin_id
--go




--  create proc AdminReviewEmp
--  @admin_id int , @emp_id int , @profile_status bit , @reason varchar(100)
--  as 
  
--  update Review_Profile
--  set profile_status='1' ,reason=null
--  where @profile_status='1' and
--  employer_id=@emp_id and admin_id=@admin_id
  
--  update Review_Profile
--  set profile_status='0' ,reason=@reason
--  where @profile_status='0'
--  and
--  employer_id=@emp_id and admin_id=@admin_id

--  go
--  --exec AdminReviewEmp 9,14,'1',null
  


--  create proc AdminViewJobs

--  as 
--  select *
--  from job

--  go
  

--  create proc AdminViewFRs

--  as 
--  select *
--  from Faculty_Representative
--  go


--create proc AddFacultyRepToII

--@job_id int ,@facultyRep_id int 
--as
--if(exists(
--select faculty_name
--from Allowed_faculties
--inner join job on job.id=Allowed_faculties.id
--inner join Industrial_Internship on Industrial_Internship.id=job.id
--inner join Faculty_Representative on Faculty_Representative.faculty=Allowed_faculties.faculty_name
--where job.id=@job_id and Faculty_Representative.id=@facultyRep_id))
--begin
-- update Industrial_Internship
-- set  facultyRep_id=@facultyRep_id
-- where id=@job_id
-- end
 

--go
----exec AddFacultyRepToII 4,27

--create proc AdminReviewJob
--@admin_id int, @job_id int , @visibility bit, @reason varchar(100)

--as 
--if(exists(
--select * 
--from job 
--inner join Admin on Admin.id =job.admin_id
--inner join Industrial_Internship on Industrial_Internship.id=job.id
--inner join Faculty_Representative on Faculty_Representative.id=Industrial_Internship.facultyRep_id
--where Industrial_Internship.Internship_status=0 and job.id=@job_id))
--begin
--set @reason='FR rejected job'
--update job 
--set visibility=0 ,reason=@reason
--where @visibility=0 and job.id=@job_id
--end
--else 
--begin
--update job 
--set visibility=1 , reason=null 
--where @visibility=1 and job.id=@job_id
--end


--go
--create proc EmpEditProfile 
-- @id int, @password varchar(8), @adress varchar(10), @company_name varchar(20), @company_phone varchar(20),@fax varchar(50), @company_website varchar(50), @type_of_business
--varchar(30), @establishment_year datetime, @origin_country varchar(20), @industry varchar(20),
--@n_current_employees int, @products_services varchar(30)
--as
--update employer
--set employer_address=@adress ,
--company_name=@company_name,
--phone_number=@company_phone,
--fax_number=@fax,
--website=@company_website,
--business=@type_of_business,
--establishment_year=@establishment_year,
--country_of_origin=@origin_country,
--industry=@industry,
--number_of_current_employees=@n_current_employees,
--products_or_services=@products_services 
--where id=@id
--update users 
--set user_password=@password
--where users.ID=@id
--go
--create proc AddContact
-- @emp_id int, @name varchar(20), @job_title varchar(30), @email varchar(50), @mobile_number varchar(20), @fax varchar(50)
-- as
-- insert into contact_person  (employer_id,contactPerson_name,job_title,email,mobile_number,fax) values ( @emp_id , @name , @job_title , @email , @mobile_number , @fax )
-- go 
--create proc AddHR 
-- @emp_id int, @name varchar(20), @email varchar(50)
-- as
-- insert into HR_Director values (@emp_id,@name,@email)
-- go 
--create proc ViewProfileStatues
--@emp_id int , @status bit OUTPUT, @reason varchar(100) OUTPUT
--as 
--select @status=profile_status ,@reason= reason
--from Review_Profile R
--where R.employer_id=@emp_id 
--print @status
--print @reason
----declare @status bit, @reason varchar(100)
--go

--create proc helperProfile 
--@emp_id int
--as 
--select profile_status 
--from Review_Profile 
--where employer_id=@emp_id
--go



--create proc PostJob
-- @emp_id int, @title varchar(30), @description varchar(50), @department varchar(20), @start_date
--datetime, @end_date datetime, @application_deadline datetime, @n_available_internships int,
--@salary_range varchar(20), @qualifications varchar(100), @location varchar(20), @application_link
--varchar(50), @application_email varchar(50), @job_type varchar(30), @workdays int,@job_id int output
--as

--if (exists(
--select  profile_status 
--from Review_Profile 
--where employer_id=@emp_id
--and profile_status='true'))
--begin
--insert into job (title,job_description,department,job_start_date,end_date,application_deadline,num_of_availabe_internships,salary_range,qualifications,job_location,application_link,application_email,job_type,employer_id)
--values ( @title , @description , @department , @start_date, @end_date , @application_deadline , @n_available_internships ,
--@salary_range , @qualifications , @location, @application_link
--, @application_email ,@job_type ,@emp_id )
--set @job_id=@@IDENTITY
--print @job_id
--if @job_type='part time'
--insert into part_time values (@@IDENTITY,@workdays)
--if @job_type='Freelance'
--insert into Freelance values (@@IDENTITY)
--if @job_type='summerInternship'
--insert into summerInternship values (@@IDENTITY)
--if @job_type='fulltime'
--begin
--insert into fulltime values (@@IDENTITY)
--end
-- else if @job_type='projectBased'
-- begin
--insert into projectBased values (@@IDENTITY)
--end
-- else if @job_type='industrial internship'
-- begin
--insert into Industrial_Internship(id,Internship_status) values (@@IDENTITY,null)
--end
--else 
--print 'job type is invalid'

--end
--else 
--print 'profile not accepted yet'
--go
----declare @job_id int 
----exec PostJob 11,'software engineer','2 yr experience','computer science','2021-07-5','2022-07-2','2021-09-1',10,'2000-30000','anything','giu',null,null,'industrial internship',null,@job_id output
----drop procedure[PostJob]

--create proc AddFaculty
-- @job_id int,@allowed_faculty varchar(20)
-- as 
-- insert into Allowed_faculties values (@job_id,@allowed_faculty)
-- go

--create proc AddSemester
-- @job_id int,@requred_semester int
-- as 
-- insert into Required_semesters values (@job_id,@requred_semester)
-- go
--create proc EmpViewJobs
-- @emp_id int
-- as 
-- select *
-- from job
-- where job.employer_id=@emp_id
-- order  by job_start_date asc 
-- go




--drop PROCEDURE [EmpViewJobs]

--create proc  EmpViewApplicants
--@emp_id int,@job_id int
--as
--select distinct s. *
--from Student s,Applies a,job j,employer e
--where s.ID=a.student_id and a.job_id=@job_id and j.id=@job_id and j.employer_id=@emp_id
--go

--exec EmpViewApplicants 10,6
--drop PROCEDURE [EmpViewApplicants]
--exec EmpViewApplicants 13,6
--create proc EmpUpdateApplicant
--@student_id int, @job_id int, @application_status varchar(20)
--as
--if(exists(
--select *
--from Eligible
--inner join Industrial_Internship on Industrial_Internship.id=Eligible.II_id
--where Eligible.student_id=@student_id and eligibility=0))
--begin
--update Applies
--set application_status='rejected'
--where student_id=@student_id and job_id=@job_id
--end
--else
--begin 
--update Applies 
--set application_status=@application_status
--where student_id=@student_id and job_id=@job_id
--end 
--go
----exec EmpViewApplicants 13,6


--create proc courseinformation 
--@facRep_id int, @job_id int, @ii_status bit output
--as 
--update Industrial_Internship
--set Internship_status=@ii_status
--where facultyRep_id=@facRep_id and id=@job_id
--go
----drop procedure [courseinformation]
--create proc StudentEditProfile
--@sid int, @email varchar(50),@first_name varchar(20),@middle_name varchar(20), @last_name
--varchar(20), @birth_date datetime,@GIU_id int,@semester int, @faculty varchar(20),@major varchar(20),@gpa decimal(4,2),@address varchar(10)
--as
--update Student
--set first_name=@first_name,middle_name=@middle_name, last_name=@last_name ,
--birth_date=@birth_date , GIU_id=@GIU_id , semester=@semester , faculty=@faculty , major=@major, GPA=@gpa , Student_Address=@address
--where s_ID=@sid
--update users
--set email=@email
--where users.ID=@sid
--go
--create proc AddMobile
--@sid int,@mobileNumber varchar(20)
--as
--insert Student_phoneNumber values (@sid ,@mobileNumber)
--go


--create proc CreateCV
--@s_id int, @personal_mail varchar(50), @education varchar(100), @extracurricular_activities
--varchar(300), @linkedIn_link varchar(30), @github_link varchar(30), @skills varchar(300), @achievements varchar(300)
--as 
--insert into CV_Builder values(@personal_mail , @education , @extracurricular_activities, @linkedIn_link , @github_link , @skills, @achievements,@s_id)

--select * 
--from CV_Builder
--where student_id=@s_id

--go


--create proc ApplyForJob 
-- @sid int, @job_id int
-- as

-- insert into Applies values(@sid , @job_id,'pending' )

-- go

-- create proc ViewMyStatus
-- @sid int, @job_id int
-- as 
-- SELECT application_status
-- from Applies
-- where student_ID=@sid AND job_ID=@job_id
-- go

-- create proc AddProgressReport
-- @sid int, @date datetime, @description varchar (100)
--as
--insert into progressReport (student_id,report_date, description) values(@sid , @date, @description)
--go

-- create proc ViewMyReports
-- @sid int, @nOfReports int output, @date datetime output, @decription varchar(100) output, @numeric_state int output, @evaluation varchar(100) output
-- as
-- select @nOfReports = count(*)
-- from progressReport
-- where progressReport.student_id=@sid;
-- print 'Total number of reports: '
-- print @nOfReports
-- update progressReport
-- set evaluation='not evaluated yet' , numeric_state= '-1'
-- where student_id=@sid and evaluation is null

-- select *
-- from progressReport 
-- where student_id=@sid 
 

-- go
----drop procedure [ViewMyReports]
---- declare  @nOfReports int , @date datetime, @decription varchar(100), @numeric_state int , @evaluation varchar(100) 
---- exec ViewMyReports 2, @nOfReports, @date, @decription, @numeric_state , @evaluation
-- create proc ViewAdvisors
-- as
-- select *
-- from Advisor
-- group by faculty
-- go
-- create proc CocViewStudents
-- @ii_id int
-- as 
-- select *
-- from Student inner join Eligible on Student.s_ID=Eligible.student_id
-- where Eligible.II_id=@ii_id
-- go
--create proc CocUpdateEligibility
-- @coc_id int, @s_id int, @ii_id int, @eligibility bit
-- as
-- update Eligible
-- set eligibility=@eligibility 
-- where student_id=@s_id and coc_id=@coc_id and II_id=@ii_id 
-- go
--create proc AAToII
-- @aa_id int, @ii_id int
-- as
-- update Industrial_Internship
-- set aa_id=@aa_id
-- where id=@ii_id and Internship_status='1'
-- go
--create proc EvalProgressReport
--@sid int, @date datetime, @numeric_state int, @evaluation varchar(100)
--as
--update progressReport
--set numeric_state=@numeric_state 
--where student_id=@sid and report_date=@date and evaluation=@evaluation
--go
--create proc ViewProgressReports
-- @advisor_id int
-- as
-- select *
-- from progressReport
-- where advisor_id=@advisor_id
-- order by report_date asc
--delete from users
--where user_password='744E5321'
--go
